package com.emp.dao;

import com.emp.dto.Emp;

public interface EmpDao {

	void insertEmp(Emp emp);
	boolean checkEmp(Emp emp);
	String forgotPassword(String emp_Name);
}
