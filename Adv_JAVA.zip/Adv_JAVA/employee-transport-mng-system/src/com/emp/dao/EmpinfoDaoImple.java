package com.emp.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.emp.dto.Empinfo;

@Repository
public class EmpinfoDaoImple implements EmpinfoDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;
	@Override
	public void insertEmpinfo(Empinfo empinfo) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(empinfo);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
		
	}

	@Override
	public void deleteEmpinfo(int empinfo_id) {

		hibernateTemplate.execute(new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Empinfo(empinfo_id));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
	}

	@Override
	public Empinfo selectEmpinfo(int empinfo_id1) {
		Empinfo empinfo = hibernateTemplate.execute(new HibernateCallback<Empinfo>() {

			@Override
			public Empinfo doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
				Empinfo ex = (Empinfo)session.get(Empinfo.class, empinfo_id1);
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}
			
		});
		return empinfo;
	}

	@Override
	public void updateEmpinfo(Empinfo empinfo) {

		hibernateTemplate.execute(new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.update(empinfo);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
	}

	@Override
	public List<Empinfo> selectAll(Empinfo emp) {
		
		List<Empinfo> empList = hibernateTemplate.execute(new HibernateCallback<List<Empinfo>>(){

			@Override
			public List<Empinfo> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				 Query q = session.createQuery("from Empinfo");
				 List<Empinfo> li = q.list();
				 System.out.println(li);
				 tr.commit();
				session.flush();
				session.close();
				return li;
				
			}
			
		});
		return empList;
	}

	@Override
	public List<Empinfo> selectAlll(int emp_Id) {
		
		List<Empinfo> empList = hibernateTemplate.execute(new HibernateCallback<List<Empinfo>>() {

			@Override
			public List<Empinfo> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Empinfo where emp_Id = ?");
				q.setInteger(0, emp_Id);
				List<Empinfo> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return empList;
	}
	}

