package com.emp.dao;

import java.util.List;

import com.emp.dto.Empinfo;

public interface EmpinfoDao {

	void insertEmpinfo(Empinfo empinfo);
	void deleteEmpinfo(int empinfo_id);
	Empinfo selectEmpinfo(int empinfo_id);
	void updateEmpinfo(Empinfo empinfo);
	
	List<Empinfo> selectAll(Empinfo emp);
	
	List<Empinfo> selectAlll(int emp_Id);
	
}
