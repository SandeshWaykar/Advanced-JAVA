package com.emp.dao;


import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.emp.dto.Emp;


@Repository
public class EmpDaoImple implements EmpDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void insertEmp(Emp emp) {
		
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(emp);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public boolean checkEmp(Emp emp) {
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Emp where emp_Name = ? and emp_Pass = ?");
				q.setString(0, emp.getEmp_Name());
				q.setString(1, emp.getEmp_Pass());
				List<Emp> li = q.list();
				boolean flag = !li.isEmpty();
				emp.setEmp_Id(li.get(0).getEmp_Id()); 
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
			
		});
		return b;
	}

	@Override
	public String forgotPassword(String emp_Name) {
		String password = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Emp where emp_Name = ?");
				q.setString(0, emp_Name);
				List<Emp> li = q.list();
				String pass = null;
				if(!li.isEmpty())
					pass = li.get(0).getEmp_Pass();
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}
			
		});
		return password;
	}
	

}
