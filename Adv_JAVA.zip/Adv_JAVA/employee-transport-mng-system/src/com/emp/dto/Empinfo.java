package com.emp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "empinfo")
public class Empinfo {

	@Id
	@Column(name = "empinfo_id")
	@GeneratedValue
	private int empinfoId;
	
	@Column(name = "emp_name")
	private String empName;
	
	@Column(name = "joining_date")
	private String joiningDate;
	
	@Column(name = "dept")
	private String Dept;
	
	@Column(name = "emp_id")
	private int emp_Id;
	
	
	public Empinfo() {
		
	}
	
	public Empinfo(int empinfoId) {
		super();
		this.empinfoId = empinfoId;
	}



	public int getEmpinfoId() {
		return empinfoId;
	}



	public void setEmpinfoId(int empinfoId) {
		this.empinfoId = empinfoId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public String getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}



	public String getDept() {
		return Dept;
	}



	public void setDept(String dept) {
		Dept = dept;
	}



	public int getEmp_Id() {
		return emp_Id;
	}



	public void setEmp_Id(int emp_Id) {
		this.emp_Id = emp_Id;
	}



	@Override
	public String toString() {
		return "Empinfo [empinfoId=" + empinfoId + ", empName=" + empName + ", joiningDate=" + joiningDate + ", Dept="
				+ Dept + ", emp_Id=" + emp_Id + "]";
	}
	
	
}
