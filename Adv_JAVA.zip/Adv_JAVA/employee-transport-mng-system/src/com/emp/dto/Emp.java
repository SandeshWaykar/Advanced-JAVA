package com.emp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Emp {

	@Id
	@GeneratedValue
	@Column(name = "emp_id")
	private int emp_Id;
	
	@Column(name = "emp_name")
	private String emp_Name;
	
	@Column(name = "emailId")
	private String emailId;
	
	@Column(name = "emp_pass")
	private String emp_Pass;
	
	@Column(name = "emp_address")
	private String emp_Address;
	@Column(name = "emp_mobileNo")
	private String emp_MobileNo;
	
	public Emp() {
		
	}

	public int getEmp_Id() {
		return emp_Id;
	}

	public void setEmp_Id(int emp_Id) {
		this.emp_Id = emp_Id;
	}

	public String getEmp_Name() {
		return emp_Name;
	}

	public void setEmp_Name(String emp_Name) {
		this.emp_Name = emp_Name;
	}

	
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmp_Pass() {
		return emp_Pass;
	}

	public void setEmp_Pass(String emp_Pass) {
		this.emp_Pass = emp_Pass;
	}

	public String getEmp_Address() {
		return emp_Address;
	}

	public void setEmp_Address(String emp_Address) {
		this.emp_Address = emp_Address;
	}

	public String getEmp_MobileNo() {
		return emp_MobileNo;
	}

	public void setEmp_MobileNo(String emp_MobileNo) {
		this.emp_MobileNo = emp_MobileNo;
	}
	
	
	
}
