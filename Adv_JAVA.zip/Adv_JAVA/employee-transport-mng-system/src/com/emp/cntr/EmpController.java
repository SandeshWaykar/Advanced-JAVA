package com.emp.cntr;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.emp.dto.Emp;
import com.emp.service.EmpService;

import com.emp.valid.UserValidator;

@Controller
public class EmpController {
	
	@Autowired
	private EmpService empService;
	@Autowired
	private UserValidator userValidator;
	@Autowired
	private MailSender mailSender;
	
	@RequestMapping(value = "/prep_reg_form.htm", method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("emp", new Emp());
		return "reg_form";
	}
	
	@RequestMapping(value = "/reg.htm", method = RequestMethod.POST)
	public String register(Emp emp, ModelMap map) {
		empService.addEmp(emp);
		return "index";
	}
	
		
	@RequestMapping(value = "/prep_login_form.htm", method = RequestMethod.GET)
	public String prepLoginForm(ModelMap map) {
		map.put("emp", new Emp());
		return "login_form";
	}
	
	@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
	public String login(Emp emp, BindingResult result,ModelMap map,HttpSession session) {
		
		userValidator.validate(emp, result);
		if(result.hasErrors()) {
			return "login_form";
		}
		
		boolean b = empService.findEmp(emp);
		if(b) {
			session.setAttribute("emp", emp);
			return "home";
		}else {
			map.put("emp", new Emp());
			return "login_form";
		}
	}
	
	
	
	@RequestMapping(value = "/forgot_password.htm",method = RequestMethod.POST)
	public String forgotPassword(@RequestParam String emp_Name,ModelMap map) {		
		String pass = empService.forgotPassword(emp_Name);
		String msg = "you are not registered";
		if(pass!=null) {
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("sandeshwaykar2017@gmail.com");  
	        message.setTo(emp_Name);  
	        message.setSubject("Your password");  
	        message.setText(pass);  
	        //sending message   
	        mailSender.send(message);
			msg = "check the mail for password";
		}
		map.put("msg", msg);
		return "info";
	}
	
}
