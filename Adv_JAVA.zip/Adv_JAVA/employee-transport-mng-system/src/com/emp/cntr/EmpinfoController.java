package com.emp.cntr;

import java.util.List;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.emp.dto.Emp;
import com.emp.dto.Empinfo;
import com.emp.service.EmpinfoService;

@Controller
public class EmpinfoController {

	@Autowired
	private EmpinfoService empinfoservice;
	@RequestMapping(value = "/prep_Emp_add_form.htm", method = RequestMethod.GET)
	public String prepEmpinfoAddForm(ModelMap map) {
		map.put("empinfo", new Empinfo());
		return "Emp_add_form";
	}
	
	
	@RequestMapping(value = "/Emp_add.htm", method = RequestMethod.POST)
	public String prepEmpinfoAdd(Empinfo empinfo ,ModelMap map, HttpSession session) {
		int empinfoId = ((Emp)session.getAttribute("emp")).getEmp_Id();
		empinfo.setEmpinfoId(empinfoId);
		empinfoservice.addEmpinfo(empinfo);
		return "home";
	}
	
	@RequestMapping(value = "/Employee_list.htm",method = RequestMethod.GET)
	public String allEmpinfo(ModelMap map,HttpSession session, Empinfo emp) {
		int empinfoId = ((Emp)session.getAttribute("emp")).getEmp_Id();
		List<Empinfo> li = empinfoservice.selectAll(emp);
		map.put("empList", li);
		return "Employee_list";
	}
	
	@RequestMapping(value = "/empinfo_delete.htm",method = RequestMethod.GET)
	public String empinfoDelete(@RequestParam int empinfoId1,ModelMap map,HttpSession session, Empinfo emp) {
		
		empinfoservice.removeEmpinfo(empinfoId1); 
		System.out.println(empinfoId1);
		int empinfoId = ((Emp)session.getAttribute("emp")).getEmp_Id();
		List<Empinfo> li = empinfoservice.selectAll(emp);
		System.out.println(li);
		map.put("empList", li);
		return "Employee_list";
	}
	
	
	
	@RequestMapping(value = "/empinfo_update_form1.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int empinfoId1,ModelMap map) {
		
		Empinfo emp = empinfoservice.findEmpinfo(empinfoId1);
		map.put("empinfo", emp);
		System.out.println(empinfoId1);
		
		return "empinfo_update_form";
	}
	
	@RequestMapping(value = "/empinfo_update.htm",method = RequestMethod.POST)
	public String productUpdate(Empinfo emp, ModelMap map, HttpSession session) {
		
		int empinfoId = ((Emp)session.getAttribute("emp")).getEmp_Id();
		emp.setEmp_Id(empinfoId);
		empinfoservice.modifyEmpinfo(emp);
			
		List<Empinfo> li = empinfoservice.selectAll(emp);
		System.out.println(li);
		map.put("empList", li);
		return "Employee_list";
	}

	
	
}
