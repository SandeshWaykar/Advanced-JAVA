package com.emp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.dao.EmpinfoDao;
import com.emp.dto.Empinfo;

@Service
public class EmpinfoServiceImple implements EmpinfoService {

	@Autowired
	private EmpinfoDao empinfoDao;
	@Override
	public void addEmpinfo(Empinfo empinfo) {

		empinfoDao.insertEmpinfo(empinfo);
	}

	@Override
	public void removeEmpinfo(int empinfo_id) {

		empinfoDao.deleteEmpinfo(empinfo_id);
	}

	@Override
	public Empinfo findEmpinfo(int empinfo_id) {
		
		return empinfoDao.selectEmpinfo(empinfo_id);
	}

	@Override
	public void modifyEmpinfo(Empinfo empinfo) {

		empinfoDao.updateEmpinfo(empinfo);
	}

	@Override
	public List<Empinfo> selectAll(Empinfo emp) {

		return empinfoDao.selectAll(emp);
	}

	@Override
	public List<Empinfo> selAlll(int emp_Id) {
		
		return empinfoDao.selectAlll(emp_Id);
	}

	
}
