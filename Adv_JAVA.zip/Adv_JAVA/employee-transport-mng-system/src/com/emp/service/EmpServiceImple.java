package com.emp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.dao.EmpDao;
import com.emp.dto.Emp;

@Service
public class EmpServiceImple implements EmpService {

	@Autowired
	private EmpDao empDao;

	@Override
	public void addEmp(Emp emp) {

		empDao.insertEmp(emp);
	}

	@Override
	public boolean findEmp(Emp emp) {
		
		return empDao.checkEmp(emp);
	}

	@Override
	public String forgotPassword(String emp_Name) {
		return empDao.forgotPassword(emp_Name);
	}
	
	
}
