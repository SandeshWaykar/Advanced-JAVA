package com.emp.service;

import com.emp.dto.Emp;

public interface EmpService {

	void addEmp(Emp emp);
	boolean findEmp(Emp emp);
	String forgotPassword(String emp_Name);
}
