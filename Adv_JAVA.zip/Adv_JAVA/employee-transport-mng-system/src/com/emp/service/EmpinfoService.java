package com.emp.service;

import java.util.List;

import com.emp.dto.Empinfo;

public interface EmpinfoService {

	void addEmpinfo(Empinfo empinfo);
	void removeEmpinfo(int empinfo_id);
	Empinfo findEmpinfo(int empinfo_id1);
	void modifyEmpinfo(Empinfo empinfo);
	
	List<Empinfo> selectAll(Empinfo emp);
	
	List<Empinfo> selAlll(int emp_Id);
}
