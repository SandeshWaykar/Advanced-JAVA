package com.emp.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.emp.dto.Emp;

@Service
public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.equals(Emp.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emp_Name","unmKey", "user name required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emp_Pass", "passKey","password required");
		
		Emp emp = (Emp)target;
		if(emp.getEmp_Pass()!=null) {
			if(emp.getEmp_Pass().length()<3) { 
				errors.rejectValue("emp_Pass", "passKey", "password should contain more 2 chars");
			}
		}
		
		
	}
	}
